function image(img) {
    var src = img.src;
    window.open(src);
}